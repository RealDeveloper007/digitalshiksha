# videoPlusCKEditorPlugin
Video plugin for CKEditor with Track (Captions/Subtitles) based on Original Video plugin from  Alfonso Martínez de Lizarrondo