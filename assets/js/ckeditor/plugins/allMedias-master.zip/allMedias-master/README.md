allmedias----- CKEditor plugin
=========

allmedias for the CKEditor's plugin,the plugin supports many medias,it's embed .

Support media format:
=========
        AVI        WMV        MPEG        MPG        MP4        FLV
        PDF        M4V        WAV        MIDI        MP3        ASF
        RM        RMVB        RA        QT        MOV        M4V
        
License
=========
Licensed under the terms of the MIT License.

Installation
=========
Extract the contents of the file into the "plugins" folder of CKEditor.
In the CKEditor configuration file (config.js) add the following code:

        config.extraPlugins = '[ allmedias ]';

If you custom the toolbar,please add 'allMedias' in 'name'.

如果你懂中文，请来 http://codeex.cn/category/web/ck ,欢迎加QQ群交流：173171134
